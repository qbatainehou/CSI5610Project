      // Task Manager App
        document.addEventListener('DOMContentLoaded', function() {
            // DOM Elements
            const taskInput = document.getElementById('taskInput');
            const addTaskBtn = document.getElementById('addTaskBtn');
            const taskList = document.getElementById('taskList');
            const filterBtns = document.querySelectorAll('.filter-btn');
            
            // Current filter
            let currentFilter = 'all';
            
            // Tasks array
            let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
            
            // Initialize app
            renderTasks();
            
            // Event Listeners
            addTaskBtn.addEventListener('click', addTask);
            taskInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    addTask();
                }
            });
            
            filterBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    // Remove active class from all buttons
                    filterBtns.forEach(b => b.classList.remove('active'));
                    // Add active class to clicked button
                    this.classList.add('active');
                    // Update current filter
                    currentFilter = this.getAttribute('data-filter');
                    // Re-render tasks with new filter
                    renderTasks();
                });
            });
            
            // Functions
            function addTask() {
                const taskText = taskInput.value.trim();
                if (taskText) {
                    const newTask = {
                        id: Date.now(),
                        text: taskText,
                        completed: false
                    };
                    
                    tasks.push(newTask);
                    saveTasks();
                    renderTasks();
                    taskInput.value = '';
                }
            }
            
            function deleteTask(id) {
                tasks = tasks.filter(task => task.id !== id);
                saveTasks();
                renderTasks();
            }
            
            function toggleTask(id) {
                tasks = tasks.map(task => {
                    if (task.id === id) {
                        return { ...task, completed: !task.completed };
                    }
                    return task;
                });
                saveTasks();
                renderTasks();
            }
            
            function editTask(id) {
                const taskItem = document.querySelector(`[data-id="${id}"]`);
                const taskTextEl = taskItem.querySelector('.task-text');
                const currentText = taskTextEl.textContent;
                
                // Create input for editing
                const editInput = document.createElement('input');
                editInput.type = 'text';
                editInput.value = currentText;
                editInput.className = 'task-editing';
                
                // Create save button
                const saveBtn = document.createElement('button');
                saveBtn.textContent = 'Save';
                saveBtn.className = 'save-btn';
                
                // Replace task text with input
                taskTextEl.replaceWith(editInput);
                
                // Replace edit button with save button
                const editBtn = taskItem.querySelector('.edit-btn');
                editBtn.replaceWith(saveBtn);
                
                // Focus on input
                editInput.focus();
                
                // Handle save
                saveBtn.addEventListener('click', saveEdit);
                editInput.addEventListener('keypress', function(e) {
                    if (e.key === 'Enter') {
                        saveEdit();
                    }
                });
                
                function saveEdit() {
                    const newText = editInput.value.trim();
                    if (newText) {
                        tasks = tasks.map(task => {
                            if (task.id === id) {
                                return { ...task, text: newText };
                            }
                            return task;
                        });
                        saveTasks();
                        renderTasks();
                    }
                }
            }
            
            function renderTasks() {
                taskList.innerHTML = '';
                
                // Filter tasks based on current filter
                const filteredTasks = tasks.filter(task => {
                    if (currentFilter === 'all') return true;
                    if (currentFilter === 'completed') return task.completed;
                    if (currentFilter === 'pending') return !task.completed;
                    return true;
                });
                
                filteredTasks.forEach(task => {
                    const taskItem = document.createElement('li');
                    taskItem.className = `task-item ${task.completed ? 'completed' : ''}`;
                    taskItem.setAttribute('data-id', task.id);
                    
                    const checkbox = document.createElement('input');
                    checkbox.type = 'checkbox';
                    checkbox.className = 'task-checkbox';
                    checkbox.checked = task.completed;
                    checkbox.addEventListener('change', () => toggleTask(task.id));
                    
                    const taskText = document.createElement('span');
                    taskText.className = 'task-text';
                    taskText.textContent = task.text;
                    
                    const actionsDiv = document.createElement('div');
                    actionsDiv.className = 'task-actions';
                    
                    const editBtn = document.createElement('button');
                    editBtn.textContent = 'Edit';
                    editBtn.className = 'edit-btn';
                    editBtn.addEventListener('click', () => editTask(task.id));
                    
                    const deleteBtn = document.createElement('button');
                    deleteBtn.textContent = 'Delete';
                    deleteBtn.className = 'delete-btn';
                    deleteBtn.addEventListener('click', () => deleteTask(task.id));
                    
                    actionsDiv.append(editBtn, deleteBtn);
                    taskItem.append(checkbox, taskText, actionsDiv);
                    taskList.appendChild(taskItem);
                });
            }
            
            function saveTasks() {
                localStorage.setItem('tasks', JSON.stringify(tasks));
            }
        });