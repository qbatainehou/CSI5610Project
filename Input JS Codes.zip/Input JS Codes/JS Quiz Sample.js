// Basic Interactive Quiz
// A simple quiz game with 10 questions and immediate feedback

// Quiz data - hardcoded array of questions
const quizData = [
    {
        question: "What is the capital of France?",
        options: ["Berlin", "London", "Paris", "Madrid"],
        answer: "Paris",
        feedback: {
            correct: "Correct! Paris is the capital of France.",
            incorrect: "Incorrect. The capital of France is Paris."
        }
    },
    {
        question: "Which planet is known as the Red Planet?",
        options: ["Earth", "Mars", "Jupiter", "Venus"],
        answer: "Mars",
        feedback: {
            correct: "Correct! Mars is known as the Red Planet.",
            incorrect: "Incorrect. Mars is known as the Red Planet."
        }
    },
    {
        question: "What is the largest mammal in the world?",
        options: ["Elephant", "Blue Whale", "Giraffe", "Polar Bear"],
        answer: "Blue Whale",
        feedback: {
            correct: "Correct! The Blue Whale is the largest mammal in the world.",
            incorrect: "Incorrect. The Blue Whale is the largest mammal in the world."
        }
    },
    {
        question: "Which element has the chemical symbol 'O'?",
        options: ["Gold", "Oxygen", "Osmium", "Oganesson"],
        answer: "Oxygen",
        feedback: {
            correct: "Correct! 'O' is the chemical symbol for Oxygen.",
            incorrect: "Incorrect. 'O' is the chemical symbol for Oxygen."
        }
    },
    {
        question: "In which year did World War II end?",
        options: ["1943", "1944", "1945", "1946"],
        answer: "1945",
        feedback: {
            correct: "Correct! World War II ended in 1945.",
            incorrect: "Incorrect. World War II ended in 1945."
        }
    },
    {
        question: "Which of these is NOT a programming language?",
        options: ["Python", "Java", "Banana", "Ruby"],
        answer: "Banana",
        feedback: {
            correct: "Correct! Banana is not a programming language.",
            incorrect: "Incorrect. Banana is not a programming language."
        }
    },
    {
        question: "What is the largest organ in the human body?",
        options: ["Heart", "Liver", "Brain", "Skin"],
        answer: "Skin",
        feedback: {
            correct: "Correct! The skin is the largest organ in the human body.",
            incorrect: "Incorrect. The skin is the largest organ in the human body."
        }
    },
    {
        question: "Who painted the Mona Lisa?",
        options: ["Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Michelangelo"],
        answer: "Leonardo da Vinci",
        feedback: {
            correct: "Correct! Leonardo da Vinci painted the Mona Lisa.",
            incorrect: "Incorrect. Leonardo da Vinci painted the Mona Lisa."
        }
    },
    {
        question: "Which country is known as the Land of the Rising Sun?",
        options: ["China", "South Korea", "Japan", "Thailand"],
        answer: "Japan",
        feedback: {
            correct: "Correct! Japan is known as the Land of the Rising Sun.",
            incorrect: "Incorrect. Japan is known as the Land of the Rising Sun."
        }
    },
    {
        question: "What is the square root of 144?",
        options: ["12", "14", "10", "16"],
        answer: "12",
        feedback: {
            correct: "Correct! The square root of 144 is 12.",
            incorrect: "Incorrect. The square root of 144 is 12."
        }
    }
];

// Quiz class to handle quiz logic
class Quiz {
    constructor(questions) {
        this.questions = questions;
        this.currentQuestionIndex = 0;
        this.score = 0;
        this.quizCompleted = false;
    }

    // Get current question
    getCurrentQuestion() {
        return this.questions[this.currentQuestionIndex];
    }

    // Check if answer is correct
    checkAnswer(answer) {
        const currentQuestion = this.getCurrentQuestion();
        const isCorrect = answer === currentQuestion.answer;
        
        if (isCorrect) {
            this.score++;
            return {
                isCorrect: true,
                feedback: currentQuestion.feedback.correct,
                correctAnswer: currentQuestion.answer
            };
        } else {
            return {
                isCorrect: false,
                feedback: currentQuestion.feedback.incorrect,
                correctAnswer: currentQuestion.answer
            };
        }
    }

    // Move to next question
    nextQuestion() {
        if (this.currentQuestionIndex < this.questions.length - 1) {
            this.currentQuestionIndex++;
            return true;
        } else {
            this.quizCompleted = true;
            return false;
        }
    }

    // Get quiz progress
    getProgress() {
        return {
            current: this.currentQuestionIndex + 1,
            total: this.questions.length,
            percentage: ((this.currentQuestionIndex + 1) / this.questions.length) * 100
        };
    }

    // Get final score
    getFinalScore() {
        return {
            score: this.score,
            total: this.questions.length,
            percentage: (this.score / this.questions.length) * 100
        };
    }

    // Reset quiz
    resetQuiz() {
        this.currentQuestionIndex = 0;
        this.score = 0;
        this.quizCompleted = false;
    }
}

// QuizUI class to handle user interaction
class QuizUI {
    constructor(quiz) {
        this.quiz = quiz;
    }

    // Display current question
    displayQuestion() {
        const question = this.quiz.getCurrentQuestion();
        const progress = this.quiz.getProgress();
        
        console.log("\n------------------------------------------------------------");
        console.log(`Question ${progress.current}/${progress.total}`);
        console.log("------------------------------------------------------------");
        console.log(question.question);
        console.log("------------------------------------------------------------");
        
        question.options.forEach((option, index) => {
            console.log(`${index + 1}. ${option}`);
        });
        
        console.log("------------------------------------------------------------");
        console.log("Enter your answer (1-4): ");
    }

    // Process user's answer
    processAnswer(userChoice) {
        // Convert 1-4 to actual option text
        const currentQuestion = this.quiz.getCurrentQuestion();
        const optionIndex = parseInt(userChoice) - 1;
        
        if (isNaN(optionIndex) || optionIndex < 0 || optionIndex >= currentQuestion.options.length) {
            console.log("Invalid choice. Please enter a number between 1 and 4.");
            return false;
        }
        
        const selectedOption = currentQuestion.options[optionIndex];
        const result = this.quiz.checkAnswer(selectedOption);
        
        console.log("\n------------------------------------------------------------");
        if (result.isCorrect) {
            console.log("✅ " + result.feedback);
        } else {
            console.log("❌ " + result.feedback);
            console.log(`The correct answer was: ${result.correctAnswer}`);
        }
        console.log("------------------------------------------------------------");
        
        return true;
    }

    // Move to next question or show final score
    continueQuiz() {
        const hasNextQuestion = this.quiz.nextQuestion();
        
        if (hasNextQuestion) {
            this.displayQuestion();
        } else {
            this.showFinalScore();
        }
    }

    // Display final score
    showFinalScore() {
        const finalScore = this.quiz.getFinalScore();
        
        console.log("\n============================================================");
        console.log("                    QUIZ COMPLETED!                         ");
        console.log("============================================================");
        console.log(`Your final score: ${finalScore.score}/${finalScore.total} (${finalScore.percentage}%)`);
        
        // Performance feedback based on score percentage
        if (finalScore.percentage >= 90) {
            console.log("Excellent job! You're a quiz master!");
        } else if (finalScore.percentage >= 70) {
            console.log("Great work! You know your stuff.");
        } else if (finalScore.percentage >= 50) {
            console.log("Good effort! Keep learning.");
        } else {
            console.log("Keep practicing. You'll do better next time!");
        }
        console.log("============================================================");
    }

    // Start the quiz
    startQuiz() {
        console.log("\n============================================================");
        console.log("                WELCOME TO THE QUIZ GAME                    ");
        console.log("============================================================");
        console.log("You will be asked 10 questions with 4 multiple-choice options.");
        console.log("Enter the number (1-4) corresponding to your answer choice.");
        console.log("Let's begin!");
        
        this.displayQuestion();
    }
}

// Simulated run of the quiz (actual implementation would use readline or DOM)
function simulateQuiz() {
    const quiz = new Quiz(quizData);
    const quizUI = new QuizUI(quiz);
    
    quizUI.startQuiz();
    
    // Simulate user answers (1-4) for each question
    // In a real application, this would be replaced with user input
    const simulatedAnswers = [3, 2, 2, 2, 3, 3, 4, 3, 3, 1]; // Example answers
    
    for (let i = 0; i < simulatedAnswers.length; i++) {
        const validAnswer = quizUI.processAnswer(simulatedAnswers[i]);
        
        if (validAnswer) {
            if (i < simulatedAnswers.length - 1) {
                console.log("\nPress any key to continue to the next question...");
                quizUI.continueQuiz();
            } else {
                // Last question
                quizUI.continueQuiz();
            }
        }
    }
    
    console.log("\nThank you for playing the quiz game!");
}

// Call the function to run the quiz
simulateQuiz();

// Example of how this could be used in a browser or with Node.js readline:
/*
// For browser:
document.getElementById('start-btn').addEventListener('click', function() {
    const quiz = new Quiz(quizData);
    const quizUI = new QuizUI(quiz);
    quizUI.startQuiz();
});

// For Node.js:
const readline = require('readline');
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function runQuiz() {
    const quiz = new Quiz(quizData);
    const quizUI = new QuizUI(quiz);
    
    quizUI.startQuiz();
    
    function askQuestion() {
        rl.question('', (answer) => {
            const validAnswer = quizUI.processAnswer(answer);
            
            if (validAnswer) {
                if (!quiz.quizCompleted) {
                    console.log("\nPress Enter to continue to the next question...");
                    rl.question('', () => {
                        quizUI.continueQuiz();
                        if (!quiz.quizCompleted) {
                            askQuestion();
                        } else {
                            rl.close();
                        }
                    });
                } else {
                    rl.close();
                }
            } else {
                askQuestion();
            }
        });
    }
    
    askQuestion();
}

runQuiz();
*/