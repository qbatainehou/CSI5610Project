function Go(instance, ctx) {
  
  var proposal = instance;
  var sourcePolicy = ctx.Db.FindByID("Policy",proposal.SourcePolicyID);
  proposal.CustomNumber1 = sourcePolicy.CustomNumber1 + 1;
  var payroll_array = ctx.Db.FindAny("Custom.PayrollSchedule","ProposalID=="+proposal.ProposalID,"PayrollNumber",100);

 var oneYearPolicy = ctx.Db.FindSingle("Policy",'MemberID=='+proposal.MemberID+'&&CustomNumber1=='+ (proposal.CustomNumber1 - 1));
 var twoYearPolicy = ctx.Db.FindSingle("Policy",'MemberID=='+proposal.MemberID+'&&CustomNumber1=='+ (proposal.CustomNumber1 - 2));
 var TwoYearBackPayroll_array = ctx.Db.FindAny("Custom.PayrollSchedule","PolicyID=="+twoYearPolicy.PolicyID,"PayrollNumber",100);	
 if(TwoYearBackPayroll_array.Length == 0) // No Payroll 
 {
	 var twoYearPolicyFromLegacy = ctx.Db.FindSingle("Policy",'MemberID=='+proposal.MemberID+'&&PolicyID<>'+twoYearPolicy.PolicyID+'&&CustomNumber1=='+ (proposal.CustomNumber1 - 2));
	 twoYearPolicy = twoYearPolicyFromLegacy;
 }
 var oneYearPayroll = 0;
 var TwoYearpayroll = 0;
	 
 if(twoYearPolicy != null) {
		 ctx.debugLog("Two Year Policy Policy existes with PolicyID =" + twoYearPolicy.PolicyID);		  
	//	 var TwoYearBackPayroll_array = ctx.Db.FindAny("Custom.PayrollSchedule","PolicyID=="+twoYearPolicy.PolicyID,"PayrollNumber",100);		  
		 var twoYearPolicyHasAudit = ctx.Db.FindAny("Custom.PayrollSchedule","PolicyID=="+twoYearPolicy.PolicyID+"&&AuditedAnnualPayroll>=0","PayrollNumber",100);
         ctx.debugLog("Two Year Policy Has an Audited items ={" + twoYearPolicyHasAudit.Length +"}");		  
		  if(twoYearPolicyHasAudit == null || twoYearPolicyHasAudit == "") // No Audit on 2 years back
		  {
					 ctx.debugLog("Two years Policy does Not have an Audit So we look into the last year");
					 if(oneYearPolicy)
					 {
                      ctx.debugLog("Loop Thru each Payroll item in the Current Proposal to update from the Previous one year Extimated Payroll");
					  for (var f=0; f < payroll_array.Length; f++) {						
							 var CurrPayroll = payroll_array[f];					 
							 ctx.debugLog("Checking Current Payroll =" + CurrPayroll.JobClassificationID);     
							 oneYearPayroll = ctx.Db.FindSingle("Custom.PayrollSchedule",'PolicyID=='+oneYearPolicy.PolicyID+'&&JobClassificationID=='+CurrPayroll.JobClassificationID);
							 if(oneYearPayroll != null) {	
                               ctx.debugLog("Upating Current Payroll =" + CurrPayroll.JobClassificationID);
                               CurrPayroll.EstimatedAnnualPayroll = (oneYearPayroll.EstimatedAnnualPayroll * 1.025);
                               ctx.Db.SaveAndApplyTriggers(CurrPayroll);
                               
								}
					  }	  
					 }
			 
		  }
		  else // if 2 years back Audited
		  {
			
			// Loop in Current  Payrolls
			for (var i=0; i < payroll_array.Length; i++) {
				 var payroll = payroll_array[i];
			  
					// Check if is it Not in 2 Years back Payrolls
				   var PayRollIncludedinTwoYearsBack = false;
					// Loop in 2 Years back  Payrolls
					for (var x=0; x < TwoYearBackPayroll_array.Length; x++) {
					  TwoYearpayroll = TwoYearBackPayroll_array[x];			  
					  if(payroll.JobClassificationID == TwoYearpayroll.JobClassificationID)
					  {
						  PayRollIncludedinTwoYearsBack = true;
					  }       
					}			
					 // Delete the Payroll from Current because it does not exist in two years back policy payroll
					 if(PayRollIncludedinTwoYearsBack == false)
					 {
						ctx.debugLog("Current payroll where JobClassification = " + payroll.JobClassification + " does not exisit in the the Audited Two years back Payrolls. So Deleting the current Payroll..."); 
						ctx.Db.DeleteRecord(payroll);  
						ctx.Db.SubmitChanges(); 
					 }            
			  }
			  
			  
			 // Loop in Two years back Payrolls
			 for (var y=0; y < TwoYearBackPayroll_array.Length; y++) {
					  var TwoYearBackpayroll = TwoYearBackPayroll_array[y];	

					// Check if is it Not in Current Payrolls
					var PayRollIncludedinCurrent = false;			  
				 
					// Loop in Current Payroll list
					for (var z=0; z < payroll_array.Length; z++) {
					  var Currentpayroll = payroll_array[z];			  
					  if(Currentpayroll.JobClassificationID == TwoYearBackpayroll.JobClassificationID)
					  {				  
						  ctx.debugLog("Two Year back payroll where JobClassification = " + TwoYearBackpayroll.JobClassification + " exisits in the the Current Payroll list")
						  ctx.debugLog("So Updating Current Payroll with the the Audited Annual Payroll");
						  Currentpayroll.EstimatedAnnualPayroll = (TwoYearBackpayroll.AuditedAnnualPayroll * 1.05)	
                          ctx.Db.SaveAndApplyTriggers(Currentpayroll);
						  PayRollIncludedinCurrent = true;
					  }    			 
					}		
					
					// Two Years back Payroll does not exist in the current payrolls
					 if(PayRollIncludedinCurrent == false)
					 {
						ctx.debugLog("Two Year back payroll where JobClassification = " + TwoYearBackpayroll.JobClassification + " does not exisit in the the Current Payroll list")
						ctx.debugLog("So Adding Pay roll to Current");
						// Need to copy from 2 years back and then update the values based on the new client requirements
						
						
						var PayRollToAdd = ctx.Db.NewInstance("Custom.PayrollSchedule");   
						
						PayRollToAdd.JobClassificationID   = TwoYearBackpayroll.JobClassificationID;
						PayRollToAdd.PayrollNumber   = TwoYearBackpayroll.PayrollNumber;                        			
						PayRollToAdd.ProposalID = proposal.ProposalID;
						PayRollToAdd.PriorPeriodPolicyID = oneYearPolicy.PolicyID;
						PayRollToAdd.Rate   = TwoYearBackpayroll.Rate; 
						PayRollToAdd.EstimatedAnnualPayroll   = (TwoYearBackpayroll.AuditedAnnualPayroll * 1.05);	
						PayRollToAdd.MemberID   = TwoYearBackpayroll.MemberID; 
						ctx.Db.SaveAndApplyTriggers(PayRollToAdd);  
					 }
			}			    
		  }
		  
 }
 else
	  if(oneYearPolicy)
			 {
			  for (var f=0; f < payroll_array.Length; f++) {						
					 var CurrPayroll = payroll_array[f];					 
					 ctx.debugLog("Checking Current Payroll ={"+ CurrPayroll.JobClassification);
					//oneYearPayroll = ctx.Db.FindSingle("Custom.PayrollSchedule",'PolicyID=='+oneYearPolicy.PolicyID+'&&PayrollNumber=="'+payroll.PayrollNumber+'"');     
					oneYearPayroll = ctx.Db.FindSingle("Custom.PayrollSchedule",'PolicyID=='+oneYearPolicy.PolicyID+'&&JobClassificationID=='+CurrPayroll.JobClassificationID);
						if(oneYearPayroll != null) {							  
							payroll.EstimatedAnnualPayroll = (oneYearPayroll.EstimatedAnnualPayroll * 1.025);
                            ctx.Db.SaveAndApplyTriggers(payroll);
							ctx.debugLog("Updating Current Payroll ={"+ CurrPayroll.JobClassification + "} from one year back");
						}
			  }	  
			 }
  
}
