 // Calendar class to handle all functionality
        class Calendar {
            constructor() {
                // Initialize properties
                this.date = new Date();
                this.currentMonth = this.date.getMonth();
                this.currentYear = this.date.getFullYear();
                this.events = this.loadEvents();
                
                // DOM elements
                this.calendarBody = document.getElementById('calendar-body');
                this.currentMonthElement = document.getElementById('current-month');
                this.prevMonthButton = document.getElementById('prev-month');
                this.nextMonthButton = document.getElementById('next-month');
                this.modal = document.getElementById('event-modal');
                this.modalDate = document.getElementById('modal-date');
                this.eventForm = document.getElementById('event-form');
                this.eventNote = document.getElementById('event-note');
                this.deleteEventButton = document.getElementById('delete-event');
                this.closeModalButton = document.querySelector('.close-modal');
                
                // Selected date for event
                this.selectedDate = null;
                
                // Initialize calendar
                this.init();
            }
            
            // Initialize calendar and set up event listeners
            init() {
                this.renderCalendar();
                this.setupEventListeners();
            }
            
            // Set up all event listeners
            setupEventListeners() {
                // Month navigation
                this.prevMonthButton.addEventListener('click', () => this.navigateMonth(-1));
                this.nextMonthButton.addEventListener('click', () => this.navigateMonth(1));
                
                // Modal events
                this.closeModalButton.addEventListener('click', () => this.closeModal());
                this.eventForm.addEventListener('submit', (e) => {
                    e.preventDefault();
                    this.saveEvent();
                });
                this.deleteEventButton.addEventListener('click', () => this.deleteEvent());
                
                // Close modal when clicking outside
                window.addEventListener('click', (e) => {
                    if (e.target === this.modal) {
                        this.closeModal();
                    }
                });
            }
            
            // Navigate to previous/next month
            navigateMonth(increment) {
                this.currentMonth += increment;
                
                // Handle year change
                if (this.currentMonth < 0) {
                    this.currentMonth = 11;
                    this.currentYear--;
                } else if (this.currentMonth > 11) {
                    this.currentMonth = 0;
                    this.currentYear++;
                }
                
                this.renderCalendar();
            }
            
            // Render the calendar based on current month and year
            renderCalendar() {
                // Update month and year display
                const months = ['January', 'February', 'March', 'April', 'May', 'June', 
                                'July', 'August', 'September', 'October', 'November', 'December'];
                this.currentMonthElement.textContent = `${months[this.currentMonth]} ${this.currentYear}`;
                
                // Clear calendar
                this.calendarBody.innerHTML = '';
                
                // Get first day of the month
                const firstDay = new Date(this.currentYear, this.currentMonth, 1).getDay();
                
                // Get number of days in the month
                const daysInMonth = new Date(this.currentYear, this.currentMonth + 1, 0).getDate();
                
                // Get current date for highlighting today
                const today = new Date();
                const isCurrentMonth = today.getMonth() === this.currentMonth && 
                                      today.getFullYear() === this.currentYear;
                
                // Create calendar cells
                let date = 1;
                for (let i = 0; i < 6; i++) {
                    // Create row
                    const row = document.createElement('tr');
                    
                    // Create cells for each day of the week
                    for (let j = 0; j < 7; j++) {
                        const cell = document.createElement('td');
                        
                        if (i === 0 && j < firstDay) {
                            // Empty cells before first day of month
                            cell.classList.add('other-month');
                        } else if (date > daysInMonth) {
                            // Empty cells after last day of month
                            cell.classList.add('other-month');
                        } else {
                            // Create day cell with date
                            const dayElement = document.createElement('div');
                            dayElement.classList.add('day');
                            
                            // Add day number
                            const dayNumber = document.createElement('div');
                            dayNumber.classList.add('day-number');
                            dayNumber.textContent = date;
                            
                            // Highlight today
                            if (isCurrentMonth && date === today.getDate()) {
                                dayElement.classList.add('today');
                            }
                            
                            // Check if day has event
                            const dateString = this.formatDateString(this.currentYear, this.currentMonth, date);
                            if (this.events[dateString]) {
                                dayElement.classList.add('has-event');
                                
                                // Add event preview
                                const eventPreview = document.createElement('div');
                                eventPreview.classList.add('event-preview');
                                eventPreview.textContent = this.events[dateString];
                                dayElement.appendChild(eventPreview);
                            }
                            
                            // Add click event to open modal
                            dayElement.addEventListener('click', () => {
                                this.openEventModal(date);
                            });
                            
                            dayElement.appendChild(dayNumber);
                            cell.appendChild(dayElement);
                            date++;
                        }
                        
                        row.appendChild(cell);
                    }
                    
                    // Add row to calendar body
                    this.calendarBody.appendChild(row);
                    
                    // Stop creating rows if we've reached the end of the month
                    if (date > daysInMonth) {
                        break;
                    }
                }
            }
            
            // Format date string for event storage (YYYY-MM-DD)
            formatDateString(year, month, day) {
                return `${year}-${month + 1}-${day}`;
            }
            
            // Open event modal for a specific date
            openEventModal(day) {
                this.selectedDate = this.formatDateString(this.currentYear, this.currentMonth, day);
                const dateObj = new Date(this.currentYear, this.currentMonth, day);
                
                // Format date for display
                const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                this.modalDate.textContent = dateObj.toLocaleDateString('en-US', options);
                
                // Load existing event if exists
                if (this.events[this.selectedDate]) {
                    this.eventNote.value = this.events[this.selectedDate];
                    this.deleteEventButton.style.display = 'block';
                } else {
                    this.eventNote.value = '';
                    this.deleteEventButton.style.display = 'none';
                }
                
                // Show modal
                this.modal.style.display = 'flex';
                this.eventNote.focus();
            }
            
            // Close event modal
            closeModal() {
                this.modal.style.display = 'none';
                this.selectedDate = null;
            }
            
            // Save event to local storage
            saveEvent() {
                const note = this.eventNote.value.trim();
                
                if (note) {
                    this.events[this.selectedDate] = note;
                } else {
                    delete this.events[this.selectedDate];
                }
                
                this.saveEvents();
                this.closeModal();
                this.renderCalendar();
            }
            
            // Delete event from local storage
            deleteEvent() {
                if (this.selectedDate && this.events[this.selectedDate]) {
                    delete this.events[this.selectedDate];
                    this.saveEvents();
                    this.closeModal();
                    this.renderCalendar();
                }
            }
            
            // Load events from local storage
            loadEvents() {
                const savedEvents = localStorage.getItem('calendar-events');
                return savedEvents ? JSON.parse(savedEvents) : {};
            }
            
            // Save events to local storage
            saveEvents() {
                localStorage.setItem('calendar-events', JSON.stringify(this.events));
            }
        }
        
        // Initialize calendar when DOM is loaded
        document.addEventListener('DOMContentLoaded', () => {
            new Calendar();
        });