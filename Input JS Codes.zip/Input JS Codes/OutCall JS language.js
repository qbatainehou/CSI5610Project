function Go(instance, ctx) { 
  try{	 
    
    var proposal = instance;
    
    ctx.DebugLog("instance.proposal: " + proposal.ProposalID);
    
    if(!isEmpty(proposal.State)){
      
     var stateDisplayCode =	proposal.State.DisplayCode;
      
     ctx.DebugLog("instance.stateID: " + stateDisplayCode);
      
     }else{
         
      return;
    }
    
    
    var premium = proposal.Premium;
    
    ctx.DebugLog("instance.premium: " + premium);
    
    var OriginalPremium = proposal.OriginalPremium;
    
    ctx.DebugLog("instance.OriginalPremium: " + OriginalPremium);
    
    var effectiveDate = proposal.EffectiveDate;
    
    ctx.DebugLog("instance.effectiveDate: " + effectiveDate);
    
    var formetEffectiveDate = formatDate(effectiveDate);
    
    ctx.DebugLog("instance.formatedeffectiveDate: " + formetEffectiveDate); 
   
    var lineOfBusiness = "GEN-1010";
    
    ctx.DebugLog("instance.lineOfBusiness" + lineOfBusiness);
    
    var proposalType = proposal.Type;
    
    ctx.DebugLog("instance.proposalType: " + proposalType);
    
    var billAmount = proposal.BillAmount;
     
    if(isEmpty(billAmount))
     
      billAmount = 0;
    
    ctx.DebugLog("instance.billAmount: " + billAmount);
    
    var boundDate = proposal.BoundDate;
    
    ctx.DebugLog("instance.boundDate: " + boundDate);
    
    var formetBoundDate = formatDate(boundDate);
    
    ctx.DebugLog("instance.formetBoundDate: " + formetBoundDate); 
    
    var cancellationStatus = proposal.CancellationStatus;
    
    ctx.DebugLog("instance.cancellationStatus: " + cancellationStatus);
    
    if('N'== proposalType ||'A' == proposalType)
      
	  var transaction_type = "PN";
   
    else if('R' == proposalType)
      
      transaction_type = "PR";
    
    else if('E' == proposalType && 'C' == cancellationStatus && compareDate(ctx,formetEffectiveDate,formetBoundDate))
    
      transaction_type = "FC";
    
    else if('E' == proposalType && billAmount >= 0)
    
      transaction_type = "APE";
    
    else if('E' == proposalType && billAmount < 0)
    
      transaction_type = "RPE";
    
    ctx.DebugLog("params.transaction_type :: " + transaction_type); 
    
    var brokerFee = proposal.CustomMoney81;
    
    ctx.DebugLog("params.brokerFee :: " + brokerFee);
    
    var inspectionFee = proposal.CustomMoney80;
    
     if(isEmpty(inspectionFee))
       
        inspectionFee = 0;
    
      ctx.DebugLog("params.inspectionFee :: " + inspectionFee); 
    
    if('E' == proposalType){
      
     brokerFee = 0;
      
    ctx.DebugLog("params.brokerFee :: " + brokerFee);
    
     var ePremium = premium - OriginalPremium
         
     ctx.DebugLog("params.ePremium :: " + ePremium);
        
    }
    if(stateDisplayCode=="CA"){
      
      inspectionFee = inspectionFee+brokerFee;
      brokerFee = 0;
      
    }
    
    if(isEmpty(brokerFee) ||isEmpty(stateDisplayCode) || isEmpty(lineOfBusiness) || isEmpty(transaction_type) || isEmpty(premium) ||isEmpty(formetEffectiveDate)){
       
      ctx.DebugLog("Error :: Please check below inputs one or more inputs are undefind or null: ");  
      
      ctx.DebugLog("instance.stateDisplayCode: " + stateDisplayCode);  
     
      ctx.DebugLog("instance.lineOfBusiness: " + lineOfBusiness);  
      
      ctx.DebugLog("instance.transaction_type: " + transaction_type);  
      
      ctx.DebugLog("instance.premium: " + premium);  
      
      ctx.DebugLog("instance.effectiveDate: " + formetEffectiveDate);
      
      ctx.DebugLog("instance.effectiveDate: " + brokerFee);
     
      
      return;
      
    } 
   
    var params = {};
    
	params.physical_state = stateDisplayCode;
    
	params.line_of_business = lineOfBusiness;
    
    params.transaction_type = transaction_type;
    
    if('E' == proposalType)
      
    params.premium = ePremium;
      
    else
   
    params.premium = premium;
    
	params.agency_fee = brokerFee;
    
	params.inspection_fee = inspectionFee;
    
	params.policy_effective_date = formetEffectiveDate;
    
    params.rpg = 0;
    
	var jsonParams = JSON.stringify(params);
    
    ctx.DebugLog("jsonParams: " + jsonParams);
    
	var url = 'https://xxxxxxxxx.inscipher.com/api/tax-calculator/calculate-general-taxes.json?apikey=ed04434d04.-r9tqbbF4LkigmMPzSRcUoel1D0-';  
   
    ctx.WebServices.AddHeader("Content-Type", "application/json");

    
    // Add this call to the Log Table
        var StateTxt = ctx.Db.FindByID("State", instance.StateID);
        var Insured = ctx.Db.FindByID("Member", instance.MemberID);    
        if(Insured && StateTxt)
        {
        logAPICall(true, Insured.Name, StateTxt.Description, instance.MemberID, ctx);
      
      //  logAPICall(true, instance.Description, instance.BrokerID, ctx);
        }
        else
        {
          ctx.DebugLog("API Log did not store because State=" + StateTxt + " and Insured =" + Insured);
        }
    
    
    
    
    
    
    
    var response = ctx.WebServices.Post(url, jsonParams);
  
    
    
    var slTax = (JSON.parse(response.Content)).sl_tax;
    
    ctx.DebugLog("slTax: " + slTax);
    
    var stamping_fee = (JSON.parse(response.Content)).stamping_fee;
    
    ctx.DebugLog("stamping_fee: " + stamping_fee);
    
    var sl_service_charge = (JSON.parse(response.Content)).sl_service_charge;
    
    ctx.DebugLog("sl_service_charge: " + sl_service_charge);
    
    var fm_tax = (JSON.parse(response.Content)).fm_tax;
      
    ctx.DebugLog("fm_tax: " + fm_tax);
   
    if(!isEmpty(slTax) && !isEmpty(stamping_fee) && !isEmpty(sl_service_charge) && !isEmpty(fm_tax)) {
    
     if('E' == proposalType){
       
      var updatedSlTax = slTax+proposal.CustomMoney82;
      
      ctx.DebugLog("updatedSlTax: " + updatedSlTax);
       
      var updatedStampingfee = stamping_fee+proposal.CustomMoney85;
      
      ctx.DebugLog("updatedStampingfee: " + updatedStampingfee);
       
      var updatedFnTax = fm_tax+proposal.CustomNumber17;
      
      ctx.DebugLog("updatedFnTax: " + updatedFnTax);
        
      var updatedSlServiceCharge = sl_service_charge+proposal.CustomNumber18;
      
      ctx.DebugLog("updatedSlServiceCharge: " + updatedSlServiceCharge);
      
      if(stateDisplayCode =='OR'){
        
      var PROPOSALSQLE = "UPDATE Proposals Set CustomMoney88 ={0}, CustomMoney89 ={1}, CustomNumber19 ={2}, CustomNumber20 ={3},  CustomMoney82 ={4}, CustomMoney85 ={5}, CustomNumber17 ={6}, CustomNumber18 ={7} WHERE ProposalID = {8}";
     
      ctx.Db.ExecuteSQLCommand(PROPOSALSQLE, [slTax,0,0,sl_service_charge,updatedSlTax,0,0,updatedSlServiceCharge,proposal.ProposalID]);
      
      }else{
        
      var PROPOSALSQLE = "UPDATE Proposals Set CustomMoney88 ={0}, CustomMoney89 ={1}, CustomNumber19 ={2}, CustomNumber20 ={3},  CustomMoney82 ={4}, CustomMoney85 ={5}, CustomNumber17 ={6}, CustomNumber18 ={7} WHERE ProposalID = {8}";
     
      ctx.Db.ExecuteSQLCommand(PROPOSALSQLE, [slTax,stamping_fee,fm_tax,sl_service_charge,updatedSlTax,updatedStampingfee,updatedFnTax,updatedSlServiceCharge,proposal.ProposalID]);
      
        
      }
       
      }else{
        
      if(stateDisplayCode =='OR'){
      
       var PROPOSALSQL = "UPDATE Proposals Set CustomMoney82 ={0}, CustomMoney85 ={1}, CustomNumber17 ={2}, CustomNumber18 ={3} WHERE ProposalID = {4}";
     
      ctx.Db.ExecuteSQLCommand(PROPOSALSQL, [slTax,0,0,sl_service_charge,proposal.ProposalID]);
       
      }else{
        
      var PROPOSALSQL = "UPDATE Proposals Set CustomMoney82 ={0}, CustomMoney85 ={1}, CustomNumber17 ={2}, CustomNumber18 ={3} WHERE ProposalID = {4}";
     
      ctx.Db.ExecuteSQLCommand(PROPOSALSQL, [slTax,stamping_fee,fm_tax,sl_service_charge,proposal.ProposalID]);
       
        
      }
     }
      
    }else {
          
     ctx.DebugLog("Getting Null or Undefined in slTax or stamping_fee values so we can not proceed with DB operations");
      
      
       // Add this call to the Log Table
        var StateTxt = ctx.Db.FindByID("State", instance.StateID);
        var Insured = ctx.Db.FindByID("Member", instance.MemberID);    
        if(Insured && StateTxt)
        {
        logAPICall(false, Insured.Name, StateTxt.Description, instance.MemberID, ctx);
      
        }
        else
        {
          ctx.DebugLog("API Log did not store because State=" + StateTxt + " and Insured =" + Insured);
        }
      
      
       
    }
    
  }catch(error){	
          
     throw error ;
    
    }
  
}

function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        
       month = '0' + month;
    
    if (day.length < 2) 
       
      day = '0' + day;

    return [year, month, day].join('-');
}

function compareDate(ctx,date1,date2) {
    
  var d1 = new Date(date1);
  
  ctx.DebugLog("Date effective: " + d1);
   
  var d2 = new Date(date2);
  
  ctx.DebugLog("Date Bound: " + d2);
   
  if (d1.getTime() === d2.getTime()){
  
    ctx.DebugLog("Date Bound: true " );   
    
    return true;
    
  }else{
      
    ctx.DebugLog("Date Bound: false " );
    
    return false;
    
  }
  
}

function isEmpty(value){
    
   return (typeof value === "undefined" || value === null);
}
 

function logAPICall(isSuccessful, Name, State, insuredNumber,ctx) {
                            var API = ctx.Db.NewInstance("Custom.APILog");                    
                            API.PoolID  = "MOXIE UNDERWRITERS";                              
                            API.APIClientName  = "InsCipher";  
                            API.IsSuccessful  = isSuccessful; //true; // or 1                              
	                        API.InsuredName = Name;
							API.InsuredNumber = insuredNumber;
    						API.State = State;  
							API.EntryDate = new Date();
                            ctx.Db.SubmitChanges();
}
