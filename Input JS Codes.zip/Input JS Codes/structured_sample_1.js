function helperFunction0(input) {
    let total = 0;
    for(let i=0; i<arr.length; i++) total += arr[i];
    return total;
}

function helperFunction1(input) {
    return str.toUpperCase();
}

function helperFunction2(input) {
    return str.toUpperCase();
}

function helperFunction3(input) {
    return Math.min(...arr);
}

function helperFunction4(input) {
    return str.split('').reverse().join('');
}


function mainProgram1() {
    console.log(helperFunction0([1,2,3,4,5]));
    console.log(helperFunction1('Hello World'));
    console.log(helperFunction2([1,2,3,4,5]));
    console.log(helperFunction3('Hello World'));
    console.log(helperFunction4([1,2,3,4,5]));

}

mainProgram1();
console.log('Padding line 33');
console.log('Padding line 34');
console.log('Padding line 35');
console.log('Padding line 36');
console.log('Padding line 37');
console.log('Padding line 38');
console.log('Padding line 39');
console.log('Padding line 40');
console.log('Padding line 41');
console.log('Padding line 42');
console.log('Padding line 43');
console.log('Padding line 44');
console.log('Padding line 45');
console.log('Padding line 46');
console.log('Padding line 47');
console.log('Padding line 48');
console.log('Padding line 49');
console.log('Padding line 50');
console.log('Padding line 51');
console.log('Padding line 52');
console.log('Padding line 53');
console.log('Padding line 54');
console.log('Padding line 55');
console.log('Padding line 56');
console.log('Padding line 57');
console.log('Padding line 58');
console.log('Padding line 59');
console.log('Padding line 60');
console.log('Padding line 61');
console.log('Padding line 62');
console.log('Padding line 63');
console.log('Padding line 64');
console.log('Padding line 65');
console.log('Padding line 66');
console.log('Padding line 67');
console.log('Padding line 68');
console.log('Padding line 69');
console.log('Padding line 70');
console.log('Padding line 71');
console.log('Padding line 72');
console.log('Padding line 73');
console.log('Padding line 74');
console.log('Padding line 75');
console.log('Padding line 76');
console.log('Padding line 77');
console.log('Padding line 78');
console.log('Padding line 79');
console.log('Padding line 80');
console.log('Padding line 81');
console.log('Padding line 82');
console.log('Padding line 83');
console.log('Padding line 84');
console.log('Padding line 85');
console.log('Padding line 86');
console.log('Padding line 87');
console.log('Padding line 88');
console.log('Padding line 89');
console.log('Padding line 90');
console.log('Padding line 91');
console.log('Padding line 92');
console.log('Padding line 93');
console.log('Padding line 94');
console.log('Padding line 95');
console.log('Padding line 96');
console.log('Padding line 97');
console.log('Padding line 98');
console.log('Padding line 99');
console.log('Padding line 100');
console.log('Padding line 101');
console.log('Padding line 102');
console.log('Padding line 103');
console.log('Padding line 104');
console.log('Padding line 105');
console.log('Padding line 106');
console.log('Padding line 107');
console.log('Padding line 108');
console.log('Padding line 109');
console.log('Padding line 110');
console.log('Padding line 111');
console.log('Padding line 112');
console.log('Padding line 113');
console.log('Padding line 114');
console.log('Padding line 115');
console.log('Padding line 116');
console.log('Padding line 117');
console.log('Padding line 118');
console.log('Padding line 119');
console.log('Padding line 120');
console.log('Padding line 121');
console.log('Padding line 122');
console.log('Padding line 123');
console.log('Padding line 124');
console.log('Padding line 125');
console.log('Padding line 126');
console.log('Padding line 127');
console.log('Padding line 128');
console.log('Padding line 129');
console.log('Padding line 130');
console.log('Padding line 131');
console.log('Padding line 132');
console.log('Padding line 133');
console.log('Padding line 134');
console.log('Padding line 135');
console.log('Padding line 136');
console.log('Padding line 137');
console.log('Padding line 138');
console.log('Padding line 139');
console.log('Padding line 140');
console.log('Padding line 141');
console.log('Padding line 142');
console.log('Padding line 143');
console.log('Padding line 144');
console.log('Padding line 145');
console.log('Padding line 146');
console.log('Padding line 147');
console.log('Padding line 148');
console.log('Padding line 149');
console.log('Padding line 150');
console.log('Padding line 151');
console.log('Padding line 152');
console.log('Padding line 153');
console.log('Padding line 154');
console.log('Padding line 155');
console.log('Padding line 156');
console.log('Padding line 157');
console.log('Padding line 158');
console.log('Padding line 159');
console.log('Padding line 160');
console.log('Padding line 161');
console.log('Padding line 162');
console.log('Padding line 163');
console.log('Padding line 164');
console.log('Padding line 165');
console.log('Padding line 166');
console.log('Padding line 167');
console.log('Padding line 168');
console.log('Padding line 169');
console.log('Padding line 170');
console.log('Padding line 171');
console.log('Padding line 172');
console.log('Padding line 173');
console.log('Padding line 174');
console.log('Padding line 175');
console.log('Padding line 176');
console.log('Padding line 177');
console.log('Padding line 178');
console.log('Padding line 179');
console.log('Padding line 180');
console.log('Padding line 181');
console.log('Padding line 182');
console.log('Padding line 183');
console.log('Padding line 184');
console.log('Padding line 185');
console.log('Padding line 186');
console.log('Padding line 187');
console.log('Padding line 188');
console.log('Padding line 189');
console.log('Padding line 190');
console.log('Padding line 191');
console.log('Padding line 192');
console.log('Padding line 193');
console.log('Padding line 194');
console.log('Padding line 195');
console.log('Padding line 196');
console.log('Padding line 197');
console.log('Padding line 198');
console.log('Padding line 199');
